(function() {
"use strict";

angular.module('admin', ['ui.router', 'common']);


})();
